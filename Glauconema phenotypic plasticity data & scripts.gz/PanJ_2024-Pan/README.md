# PanJ_2024
Molecular basis and evolution of phenotypic plasticity in the marine ciliate Glauconema
